console.log(url);


let lis = document.querySelectorAll(".list li");
let lastIndex = 0;

lis.forEach((li, index) => {
    li.onclick = function () {
        // lis[lastIndex].classList.remove("sel");
        // this.classList.add("sel");
        // lastIndex = index;
        location.href = this.dataset.url;
    }
});


let datas = [
    "露娜", "张良", "王昭君"
];

/*
loaddingWrap(".wrap", datas, () => {
    let wrap_lis = document.querySelectorAll(".wrap li");
    console.log(wrap_lis);
});*/

loaddingWrap(".wrap", datas).then(() => {
    let wrap_lis = document.querySelectorAll(".wrap li");
    console.log(wrap_lis);
})


