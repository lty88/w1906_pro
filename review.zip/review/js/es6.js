// ECMAScript 是JavaScript 标准
// # let & const
const a = 10; // 常量、不可修改

var x = 20;
var x = 'hello';
let y = 20;
// let y = 'hello';
// let关键字定义的变量不可修改
{
    let m = 0;
}
// console.log(m);
// let关键字会形成块级作用域
// 局部作用于、全局作用域、块级作用域

// # 变量解构
let name = 'lihy', age = 38;
let obj = {
    name,
    age
};
console.log(obj);

let o = {
    job: "前端工程师",
    city: "成都"
};
let { job, city } = o;
console.log(job, city, o);

let [n1, n2] = [1, 2];
console.log(n1, n2);
[n1, n2] = [n2, n1];
console.log(n1, n2);


// # 扩展运算符 ...
let nums = [1, 3, 2, 11, 3, 5];
// 最大值 
/*
let min = nums[0];
let max = nums[0];
nums.forEach(num => {
    min = num < min ? num : min;
    max = num > max ? num : max;
})
console.log(min, max);*/
let min = Math.min(...nums);
let max = Math.max(...nums)
console.log(min, max);

// 数组去重 Set：集合 => 集合内的元素不重复
console.log([...new Set(nums)]);


// # 箭头函数
/*
let sum = (a, b) => a + b;
let sum = (a, b) => { return a + b;}
let sum = function(a, b) {
    return a + b;
}*/

/*
function sum(a, b, name) {
    a = a == undefined ? 0 : a;
    b = b == undefined ? 0 : b;
    name = name || "耀哥";
    console.log(name);
    return a + b;
}
console.log(sum(1, 2, "lihy"));*/
function test(a = 1, b = 1, name = "lihy"){
    console.log(a, b, name);
}
test();


function sum(...nums) {
    // arguments = Array.from(arguments);
    // arguments= Array.prototype.slice.call(arguments);
    // arguments = [...arguments];
    console.log(nums);
}

console.log(sum(1, 2, 3, 4, 5 ));


// # class
function Person(name, age) {
    this.name = name;
    this.age = age;
    this.sayHi = function() {
        console.log("hi");
    }
}
let per1 = new Person("admin", 29);

class Teacher  {
    // 构造函数
    constructor(name, address, tel) {
        // 属性
        this.name = name;
        this.address = address;
        this.tel = tel;
    }
    // 类方法（静态方法）
    static sayGG() {
        console.log("GG");
    }
    // 实例方法
    sayHell() {
        console.log("hello");
    }
}

let tea = new Teacher("耀哥", "四川成都", "17398888669")
console.log(tea);
tea.sayHell();
Teacher.sayGG();
// 类：抽象
// 对象：具体
// 对象是类的实例
// 创建一个对象 = new 一个对象 = 实例化一个对象

class Calc {
    constructor(firnum, secnum, oprator) {
        this.firnum = firnum;
        this.secnum = secnum;
        this.oprator = oprator;
    }
    add() {

    }
    // ...
}







