function loaddingWrap(sel, data, callback) {
    setTimeout(() => {
        let el = document.querySelector(sel);
        let htmlStr = "";
        data.forEach(name => {
            htmlStr += `<li>${name}</li>`
        });
        el.innerHTML = htmlStr;
        callback && callback();
    }, 500);
}

function loaddingWrap(sel, data) {
    // resolve 成功回调
    // reject 失败回调
    return new Promise((resolve, reject) => {
        let el = document.querySelector(sel);
        let htmlStr = "";
        data.forEach(name => {
            htmlStr += `<li>${name}</li>`
        });
        el.innerHTML = htmlStr;
        resolve();
    })
}
