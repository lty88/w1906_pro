const BASE_URL = "http://10.2.1.21:80";
//发送登陆数据
let phone = document.querySelector(".tel");
let password = document.querySelector(".pass");
let btn = document.querySelector(".btn");
let loadtips1 = document.querySelector(".loadtips1");
let loadtips2 = document.querySelector(".loadtips2");

btn.onclick = function(){
    // console.log(phone.value);

    fetch(`${BASE_URL}/login`, {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify({
            tel: phone.value,
            password: password.value,
        })
    }).then(res => {        
        return res.json();
    }).then(data => {
        console.log(data);
        if(data.code == 200){
            window.location.href="http://www.miniso.cn/";
        }else if(data.data == "用户不存在"){
            loadtips1.style.display = "block";
        }else{
            loadtips2.style.display = "block";
        }       
    });
}