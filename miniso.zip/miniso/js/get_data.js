const BASE_URL = "http://10.2.1.21:80";
//--------------------获取banner图片----------------------
fetch(`${BASE_URL}/data`).then(res => {
    return res.json();
}).then(data => {
    let imgs = document.querySelector(".imgs");
    let banItem = "";
    imgArr = data.data;
    imgArr.forEach(link => {
        // console.log(link.pname);
        banItem += `<img class="banner_img" src="${link.pname}" alt="">`;
    });
    imgs.innerHTML = banItem;
    // console.log(imgs.innerHTML);
    banner();
});

//将操作banner的js封装成函数写在获取服务器返回数据的方法外，再在上述方法中调用，可避免《动态生成的》元素无法获取 
function banner() {
    // 1. 获取元素
    //1.1 获取第一个img元素，并添加 show 类名 
    let firstImg = document.querySelector(".imgs img:nth-child(1)");
    firstImg.classList.add("show");
    let imgs = [...$(".banner_img", true)];
    let prev = $(".prev");
    let next = $(".next");
    let idots = [...$(".idot", true)];
    let _curIndex = 0; // 记录当前显示图片的下标
    let _lastIndex = 0;
    let _timer = null; // 定时器
    // 2. 点击下一页
    next.onclick = function () {
        _curIndex = _curIndex == 6 ? 0 : ++_curIndex;
        tab();
    }
    // 3. 点击上一页
    prev.onclick = function () {
        _curIndex = _curIndex == 0 ? 6 : --_curIndex;
        tab();
    }
    // 4. 点击小圆点
    idots.forEach(function (idot, index) {
        idot.onclick = function () {
            _curIndex = index;
            tab();
        }
    })
    // 5. 自动播放
    play();
    // 6. 用户体验
    let container = $(".container");
    container.onmouseenter = stop;
    container.onmouseleave = play;

    // 启动定时器
    function play() {
        _timer = setInterval(function () {
            next.onclick();
        }, 2000);
    }
    // 关闭定时器
    function stop() {
        clearInterval(_timer);
    }
    // 切换
    function tab() {
        // 切换图片
        imgs[_lastIndex].classList.remove("show");
        imgs[_curIndex].classList.add("show");
        // 切换小圆点
        idots[_lastIndex].classList.remove("sel");
        idots[_curIndex].classList.add("sel");
        _lastIndex = _curIndex;
    }
    // 获取元素
    function $(sel, isAll) {
        if (isAll) {
            return document.querySelectorAll(sel);
        }
        return document.querySelector(sel);
    }
}

//------------------获取商品展示数据------------------------
fetch(`${BASE_URL}/data/miniimg1`).then(res => {
    return res.json();
}).then(data => {
    let minione = document.querySelector(".minione");
    let showItem = "";
    showArr = data.data;
    showArr.forEach(mimg => {
        showItem += `
        <li class="miniimg">
            <a href="${mimg.mlink}">
                <img src="${mimg.img}" alt="">
                <p>${mimg.p}</p>
                <span>${mimg.s}</span>
            </a>
        </li>
        `;
    });
    minione.innerHTML = showItem;
});

fetch(`${BASE_URL}/data/miniimg2`).then(res => {
    return res.json();
}).then(data => {
    let minitwo = document.querySelector(".minitwo");
    let showItem = "";
    showArr = data.data;
    showArr.forEach(mimg => {
        showItem += `
        <li class="miniimg">
            <a href="${mimg.mlink}">
                <img src="${mimg.img}" alt="">
                <p>${mimg.p}</p>
                <span>${mimg.s}</span>
            </a>
        </li>
        `;
    });
    minitwo.innerHTML = showItem;
});

