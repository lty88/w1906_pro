


//------------------------subnav-----------------------------

let oNav=[...document.querySelectorAll(".navlist li")];
let oDiv = [...document.querySelectorAll(".product_show")];

for (var i = 0; i < oNav.length; i++) {
    oNav[i].index = i;
    oNav[i].onmouseenter = function () {
        for (var i = 0; i < oNav.length; i++) {
            oNav[i].className = '';
            oDiv[i].style.display = "none";
        }
        this.className = 'act';
        oDiv[this.index].style.display = "block" 
    }
    for (var j = 1; j < oNav.length; j++) {
        oNav[j].className = '';
        oDiv[j].style.display = "none";
    }
}



