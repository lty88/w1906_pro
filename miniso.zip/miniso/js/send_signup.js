const BASE_URL = "http://10.2.1.21:80";
//发送注册信息

let username = document.querySelector("#username");
let tel = document.querySelector("#tel");
let password1 = document.querySelector("#password1");
let submit = document.querySelector("#submit");
let tips1 = document.querySelector(".tips1");
let tips2 = document.querySelector(".tips2");
submit.onclick = function(){
    fetch(`${BASE_URL}/register`, {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify({
            username: username.value,
            password: password1.value,
            tel: tel.value
        })
    }).then(res => {        
        return res.json();
    }).then(data => {
        // console.log(data);
        if(data.data == "注册成功"){
            window.location.href="../index.html";
        }else if(data.data == "用户已存在"){
            tips1.style.display = "block";
        }else{
            tips2.style.display = "block";
        }
    });
}


