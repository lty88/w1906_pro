// ------------------------回到顶部----------------------
//记录窗口滚动距离
let _offset = 0;
//监听窗口滚动
window.onscroll = function () {
    //获取窗口滚动的距离
    _offset = document.body.scrollTop || document.documentElement.scrollTop
}
//点击按钮
let top1 = document.querySelector(".top");
console.log(top)
top1.onclick = function () {
    // duration 持续时间 完成一次动画的持续时间
    // interval 每一帧持续的时间
    // frames = durtaion / interval 帧数
    // _offset 位移的距离
    // speed = _offset / frames 每一帧位移的距离
    let duration = 500;
    let interval = 15;
    let frames = duration / interval;
    let speed = Math.ceil(_offset / frames);
    let t = setInterval(() => {
        //在现有的基础上减speed
        document.body.scrollTop = document.documentElement.scrollTop = _offset - speed;
        if (_offset <= 0) {
            clearInterval(t);
            //矫正误差
            document.body.scrollTop = document.documentElement.scrollTop = 0;
        }
    }, interval);
}