const BASE_URL = "http://10.2.1.21:80";
//--------------------获取购物车商品数据----------------------
fetch(`${BASE_URL}/shoppingcart/getpr`).then(res => {
    return res.json();
}).then(data => {
    // console.log(data);
    let cartList = document.querySelector(".cart-list");
    let item = "";
    data.data.forEach(pr => {
        item = `
            <li>
                <div class="checkbox box"></div>
                <div class="imgbox">
                    <a href="http://10.2.1.21:5500/pages/product_details.html" target="_blank">
                        <img src="${pr.img}"
                            alt="">
                    </a>
                </div>
                <div class="proname">
                    <p>${pr.prname}</p>
                    <br>
                    <span>香味：${pr.type}</span>
                </div>
                <div class="price">
                <span>￥</span>
                <span class="unitprice">${pr.unitprice}</span>
                </div>
                <div class="_count">
                    <div class="_comm _reduce">-</div>
                    <input type="text" class="_num" value="${pr.number}">
                    <div class="_comm _add">+</div>
                </div>
                <div class="subtotal">
                <span>￥</span>
                <span class="subto">${pr.unitprice}</span>
                </div>
                <div class="del"></div>
                <div class="stock" data-stock="${pr.stock}"></div>
            </li> 
        `;
        cartList.innerHTML += item;
    });
    cart();
});

//----------------------------购物车数据计算------------------------------
function cart() {
    let lis = [...document.querySelectorAll(".cart-list li")];
    let unitprice = [...document.querySelectorAll(".unitprice")];
    let _num = [...document.querySelectorAll("._num")];
    let subto = [...document.querySelectorAll(".subto")];
    let numAdd = [...document.querySelectorAll("._add")];
    let numReduce = [...document.querySelectorAll("._reduce")];
    let stock = [...document.querySelectorAll(".stock")];
    let checkbox = [...document.querySelectorAll(".checkbox")];
    let money = document.querySelector(".money");

    var i = "";
    for (var i = 0; i < lis.length; i++) {
        //隐藏商品库
        stock[i].style.color = "#fff";

        // ---------------------小计-------------------------
        // 初始的小计
        subto[i].innerHTML = `${(unitprice[i].innerHTML * _num[i].value).toFixed(2)}`;

        //通过 闭包函数 使得 点击事件 能够访问上面for循环中的 局部变量i
        (function (i) {
            numAdd[i].onclick = function () {
                //判断是否超过库存      
                if (parseInt(_num.value) == (parseInt(stock[i].innerHTML))) {
                    _num[i].value = parseInt(stock[i].innerHTML);
                } else {
                    _num[i].value = parseInt(_num[i].value) + 1;
                }
                //点击加减后的小计
                subto[i].innerHTML = `${(unitprice[i].innerHTML * _num[i].value).toFixed(2)}`;
            }

            numReduce[i].onclick = function () {
                if (_num[i].value <= 0) {
                    _num[i].value = 0;
                } else {
                    _num[i].value = parseInt(_num[i].value) - 1;
                }
                subto[i].innerHTML = `${(unitprice[i].innerHTML * _num[i].value).toFixed(2)}`;
            }

            //-----------------选择结算商品,并给出总价--------------

            checkbox[i].onclick = function () {
                //将选择的商品小计赋值给结算总价
                // console.log(checkbox[i].classList.contains("check"))
                if (checkbox[i].classList.contains("check") == true) {
                    checkbox[i].classList.remove("check");
                } else {
                    checkbox[i].classList.add("check");
                }

                //----------------结算价格--------------------
                //通过判断 checkbox标签 是否含有 check类 来获取被选取的商品，从而统计总价
                let totals = 0;
                let num = 0;
                
                let select = [...document.querySelectorAll(".check")];              
                if(select.length == 0){
                    money.innerHTML = 0
                }else{
                    for (var j = 0; j < select.length; j++) {
                        num =  parseFloat(subto[j].innerHTML);
                        totals += num;  
                    }
                    money.innerHTML = totals;    
                }
            }

            //------------------删除按钮-------------------------
            let del = [...document.querySelectorAll(".del")];
            let cartLi = [...document.querySelectorAll(".cart-list li")];
            del[i].onclick = function(){
                cartLi[i].innerHTML = "";
            }
        })(i);
    }
}









