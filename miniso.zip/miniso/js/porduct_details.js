(function () {
    //-----------------图片展示--------------
    let minipicItem = [...document.querySelectorAll(".minipic_item li img")];
    let bigpic = document.querySelector(".bigpic img");
    // console.log(minipicItem)

    for (var i = 0; i < minipicItem.length; i++) {
        minipicItem[i].onmouseenter = function () {
            //将小图地址赋值给大图显示框
            bigpic.src = this.src;
            // console.log(this.src);
        }
    }

    //--------------选择规格-------------------
    let typeArr = [...document.querySelectorAll(".choice li")];
    let stock = document.querySelector(".stocknum");
    //默认显示第一个规格的库存数
    stock.value = typeArr[0].getAttribute("data-stock");
    typeArr.forEach(list => {
        list.onclick = function () {
            //选中规格后，购买数量显示要置0
            num.value = 0;

            //给选中规格加样式
            // 1. 先遍历所有规格，将有class的置为空
            typeArr.forEach(_list => {
                _list.className = "";
            })
            // 2. 给当前被点击规格添加样式class                
            this.className = "redborder";

            //点击相应规格后大图展示相应改变
            //1. 通过给元素标签添加 data-img 自定义属性来存取对应图片地址
            //2. 将当前被点击规格对应图片地址赋值给大图显示框
            //3. （也可将图片存在一个数组中，用获取的 规格数组下标 来获取对应图片）
            bigpic.src = this.getAttribute("data-img");

            //规格对应库存显示
            stock.value = this.getAttribute("data-stock");
        }
    })

    //--------------加减商品计数显示---------------
    let numAdd = document.querySelector(".add");
    let numReduce = document.querySelector(".reduce");
    let num = document.querySelector(".num");
    let stocknum = document.querySelector(".stocknum");

    numAdd.onclick = function () {
        // console.log(typeof(num.value))
        //判断是否超过库存       
        if (parseInt(num.value) == parseInt(stocknum.value)) {
            num.value = parseInt(stocknum.value);
        } else {
            num.value = parseInt(num.value) + 1;
        }
    }

    numReduce.onclick = function () {
        if (num.value <= 0) {
            num.value = 0;
        } else {
            num.value = parseInt(num.value) - 1;
        }
    }

    //-------------------添加购物车--------------------
    const BASE_URL = "http://10.2.1.21:80";
    //发送添加购物车数据
    let addShopcar = document.querySelector(".add-shopcar");
    let prName = document.querySelector(".prright > h2");
    let unitPrice = document.querySelector(".mondata");
    addShopcar.onclick = function () {
        //获取当前选中规格的 文本内容 和 对应的图片地址
        let typeName = "";
        typeArr.forEach(list => {
            //通过遍历 判断class是否含有 redborder 值，从而得到当前被选中的元素
            if(list.classList.contains("redborder")){
                typeName = list.innerHTML;
                typeImg = list.getAttribute("data-img");
                typeStock = list.getAttribute("data-stock");
            }          
        })

        fetch(`${BASE_URL}/shoppingcart`, {           
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                prname: prName.innerHTML,
                number: num.value,
                type: typeName,
                img: typeImg,
                unitprice: unitPrice.innerHTML,
                stock: typeStock
            })
        }).then(res => {
            return res.json();
        }).then(data => {
            console.log(data);           
        });
    }
})();