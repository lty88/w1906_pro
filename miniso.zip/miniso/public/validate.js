let validateFormOpt = {
    fieldsOpt: {
        username: {
            rule: { reg: /^[a-zA-Z]\w{5}/ },
            successMsg: " ",
            errorMsg: "用户名格式不正确",
            selector: '#username'
        },
        tel: {
            rule: { reg: /^1[2-9]\d{9}$/ },
            successMsg: " ",
            errorMsg: "电话号码格式不正确",
            selector: '#tel'
        },        
        password1: {
            rule: { reg: /^.{6,16}$/ },
            successMsg: " ",
            errorMsg: "密码长度为6-16位",
            selector: '#password1'
        },
        password2: {
            rule: { reg: /^.{6,16}$/, equal: 'password1' },
            successMsg: " ",
            errorMsg: "两次密码不一样",
            selector: '#password2'
        },
    },
    submit: {
        selector: '#submit'
    },
    success: function (e) {
        e.preventDefault()
        // console.log('验证成功')
    },
    error: function (e) {
        e.preventDefault()
        // console.log('验证失败')
    }
}


function ValidateForm(validateFormOpt) {


    //初始化输入字段配置
    this._initValiFields = function () {
        this.fieldsOpt = validateFormOpt.fieldsOpt
    }
    //根据slector找到对应的输入字段元素

    this._getIpts = function () {
        //输入框元素
        this.iptEle = {}
        for (let key in this.fieldsOpt) {
            this.iptEle[key] = document.querySelector(this.fieldsOpt[key].selector)
        }
    }

    //初始化验证结果对象
    this._initValiRes = function () {
        //验证结果
        let valiResObj = {}
        for (let field in this.fieldsOpt) {
            valiResObj[field] = false
        }
        //验证结果对象添加pass属性，
        Object.defineProperty(valiResObj, 'pass', {
            get() {
                let res = true
                for (let key in this) {
                    res = res && this[key]
                    if (!res) { break }
                }
                return res
            }
        })
        this.valiRes = valiResObj
    }
    //给所有字段绑定失去焦点事件
    this.bindFieldEvent = function () {
        for (let field in this.fieldsOpt) {
            //更具字段找到当前验证的元素
            let curIpt = this.iptEle[field]
            let _this = this
            // console.log(this)
            curIpt.onblur = function () {
                // console.log(this)
                //this指向当前元素
                let value = this.value
                _this.valiRes[field] = _this._valiField(field, value)
                
            }
        }
    }
    
    //验证一个字段
    this._valiField = function (field, value) {
        let reg = this.fieldsOpt[field].rule.reg
        let valiRes = reg.test(value)
        this._handleFieldRes(field, valiRes)
        return valiRes
    }
    //处理字段验证结果
    this._handleFieldRes = function (field, valiRes) {
        let curIpt = this.iptEle[field]
        let infoSpan = curIpt.nextElementSibling
        if (valiRes) {
            //如果该字段验证成功
            curIpt.parentElement.classList.add('has-success')
            curIpt.parentElement.classList.remove('has-error')
            infoSpan.innerText = this.fieldsOpt[field].successMsg
            // console.log(`${field}验证成功`)
        } else {
            curIpt.parentElement.classList.remove('has-success')
            curIpt.parentElement.classList.add('has-error')
            infoSpan.innerText = this.fieldsOpt[field].errorMsg
            // console.log(`${field}验证失败`)
        }
    }

    this._handleSubmit = function (validateFormOpt) {
        let submit = document.querySelector(validateFormOpt.submit.selector)
        let _this = this
        submit.addEventListener('click', function (e) {
            if (!_this.isPass()) {
                validateFormOpt.error(e)
            } else {
                validateFormOpt.success(e)
            }

        })
    }

    //让元素获得焦点
    this._focus = function (field) {
        this.iptEle[field].focus()
    }

    //表单所有字段验证结果
    this.isPass = function () {
        return this.valiRes.pass
    }

    //开启实例表单验证
    this.validate = function () {
        this.bindFieldEvent()
        this._handleSubmit(validateFormOpt)
    }


    /********************调用函数,实现数据初始化*****************************/
    //初始化字段配置
    this._initValiFields()
    //初始化字段对应的元素
    this._getIpts()
    //初始化字段验证结果
    this._initValiRes()







}
let vf = new ValidateForm(validateFormOpt)
//开启表单验证
vf.validate()
