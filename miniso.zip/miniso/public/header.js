//---------------------herder部分-----------------
//导航下划线
let navs = [...document.querySelectorAll(".nav")];
let navLines = [...document.querySelectorAll(".nav_line")];
let y = 0;
let _curIndex = 0;
let _lastIndex = 0;

navs.forEach(function (nav, index) {
    nav.onmouseover = function () {
        _curIndex = index;
        tab();
    }
})

function tab() {
    navLines[_lastIndex].classList.remove("show");
    navLines[_curIndex].classList.add("show");
    _lastIndex = _curIndex;
}