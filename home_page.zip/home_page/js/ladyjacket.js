

$.ajax({
  url: `${BASE_URL}/ladyclothes?type=外套`,
  type: "get",
  //数据格式
  dataType: "json"
})
  .done(res => {
    console.log(res.data);
    let letchovre = document.querySelector(".container-right-comment");

    let htmlStr = "";
    res.data.forEach((items, index) => {
      htmlStr += `
      <div class="relaxation correlation-pic">
                  <img class="omg" src="${items.name}" alt="loding" />
                  <h4>${items.ind}</h4>
                  <h6>${items.price}</h6>
                </div>
    `;
    });

    letchovre.innerHTML = htmlStr;
    getomg();
  })
  .fail(err => {
    console.log(err);
  });


